## 0.3.0 (2019-04-04)

* Make compatible with acorn-bigint

## 0.2.0 (2018-09-14)

* Update to new acorn 6 interface
* Change license to MIT

## 0.1.1 (2018-01-16)

* Don't bail on empty integers as in `1.`

## 0.1.0 (2017-12-19)

Initial release

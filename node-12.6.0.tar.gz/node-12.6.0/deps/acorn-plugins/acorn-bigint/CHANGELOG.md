## 0.4.0 (2019-04-04)

* Make compatible with acorn-numeric-separator

## 0.3.1 (2018-10-06)

* Fix creation of BigInt values everywhere (Thanks, Gus Caplan!)

## 0.3.0 (2018-09-14)

* Update to new acorn 6 interface
* Actually support creating BigInt values in AST in Chrome
* Change license to MIT

## 0.2.0 (2017-12-20)

* Emit BigInt values in AST if supported by runtime engine

## 0.1.0 (2017-12-19)

Initial release
